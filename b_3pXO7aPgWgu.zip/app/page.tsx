"use client";

import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { HeroSection } from "@/components/home/hero-section";
import { FeaturesSection } from "@/components/home/features-section";
import { ServicesSection } from "@/components/home/services-section";
import { ProjectsSection } from "@/components/home/projects-section";
import { CalculatorsPreview } from "@/components/home/calculators-preview";
import { AIToolsPreview } from "@/components/home/ai-tools-preview";
import { ContactSection } from "@/components/home/contact-section";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <FeaturesSection />
        <ServicesSection />
        <CalculatorsPreview />
        <AIToolsPreview />
        <ProjectsSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
