"use client";

import { useState, useRef, useEffect } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, User, Send, Sparkles, AlertTriangle, RefreshCw } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";

const suggestedQuestions = [
  "What are my fundamental rights under the Indian Constitution?",
  "How do I file a consumer complaint?",
  "What is the process for property registration?",
  "What are the grounds for divorce in India?",
  "How can I recover money from a defaulter?",
  "What are the rights of tenants in India?"
];

export default function AIAssistantPage() {
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { messages, sendMessage, status, error, reload } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
  });

  const isLoading = status === "streaming" || status === "submitted";

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    sendMessage({ text: input });
    setInput("");
  };

  const handleSuggestedQuestion = (question: string) => {
    sendMessage({ text: question });
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-8">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-4xl">
            {/* Header */}
            <div className="mb-8 text-center">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
                <Sparkles className="h-4 w-4" />
                Free AI Legal Assistant
              </div>
              <h1 className="mb-2 text-3xl font-bold">NyayaSetu AI</h1>
              <p className="text-muted-foreground">
                Get instant answers to your legal questions. Available 24/7.
              </p>
            </div>

            {/* Disclaimer */}
            <Card className="mb-6 border-amber-500/20 bg-amber-500/5">
              <CardContent className="flex items-start gap-3 p-4">
                <AlertTriangle className="h-5 w-5 shrink-0 text-amber-500" />
                <p className="text-sm text-muted-foreground">
                  This AI provides general legal information, not legal advice. 
                  For specific legal matters, please consult a qualified advocate.
                </p>
              </CardContent>
            </Card>

            {/* Chat Area */}
            <Card className="mb-4">
              <CardContent className="p-0">
                <div className="h-[500px] overflow-y-auto p-4">
                  {messages.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center">
                      <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 text-primary">
                        <Bot className="h-10 w-10" />
                      </div>
                      <h3 className="mb-2 text-lg font-semibold">Start a Conversation</h3>
                      <p className="mb-6 text-center text-sm text-muted-foreground">
                        Ask me anything about Indian law, legal procedures, or your rights.
                      </p>
                      
                      {/* Suggested Questions */}
                      <div className="w-full max-w-lg space-y-2">
                        <p className="text-center text-xs font-medium text-muted-foreground">
                          Try asking:
                        </p>
                        <div className="flex flex-wrap justify-center gap-2">
                          {suggestedQuestions.slice(0, 4).map((question, index) => (
                            <button
                              key={index}
                              onClick={() => handleSuggestedQuestion(question)}
                              className="rounded-full border border-border bg-background px-3 py-1.5 text-xs transition-colors hover:bg-muted"
                            >
                              {question.slice(0, 40)}...
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex gap-3 ${
                            message.role === "user" ? "justify-end" : "justify-start"
                          }`}
                        >
                          {message.role === "assistant" && (
                            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                              <Bot className="h-4 w-4" />
                            </div>
                          )}
                          <div
                            className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                              message.role === "user"
                                ? "bg-primary text-primary-foreground"
                                : "bg-muted"
                            }`}
                          >
                            <div className="whitespace-pre-wrap text-sm">
                              {message.parts.map((part, index) => {
                                if (part.type === "text") {
                                  return <span key={index}>{part.text}</span>;
                                }
                                return null;
                              })}
                            </div>
                          </div>
                          {message.role === "user" && (
                            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
                              <User className="h-4 w-4" />
                            </div>
                          )}
                        </div>
                      ))}
                      
                      {isLoading && messages[messages.length - 1]?.role === "user" && (
                        <div className="flex gap-3">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                            <Bot className="h-4 w-4" />
                          </div>
                          <div className="rounded-2xl bg-muted px-4 py-3">
                            <Spinner className="h-4 w-4" />
                          </div>
                        </div>
                      )}
                      
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </div>

                {/* Error State */}
                {error && (
                  <div className="border-t border-border bg-destructive/10 p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-destructive">
                        An error occurred. Please try again.
                      </p>
                      <Button variant="outline" size="sm" onClick={() => reload()}>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Retry
                      </Button>
                    </div>
                  </div>
                )}

                {/* Input Form */}
                <div className="border-t border-border p-4">
                  <form onSubmit={handleSubmit} className="flex gap-2">
                    <Textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Ask your legal question..."
                      className="min-h-[60px] resize-none"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSubmit(e);
                        }
                      }}
                      disabled={isLoading}
                    />
                    <Button type="submit" size="lg" disabled={isLoading || !input.trim()}>
                      {isLoading ? (
                        <Spinner className="h-4 w-4" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <div className="text-center text-xs text-muted-foreground">
              <p>Press Enter to send, Shift+Enter for new line</p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
